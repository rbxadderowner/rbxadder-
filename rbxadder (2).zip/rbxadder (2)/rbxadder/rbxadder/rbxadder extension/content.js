let animationRunning = false;

function animateRobux(amount) {
    const robuxElement = document.getElementById('nav-robux-amount');
    if (!robuxElement) {
        console.error("Robux element 'nav-robux-amount' not found");
        return;
    }

    let currentAmount = 0;
    const currentText = robuxElement.innerText.replace(/,/g, '');
    const parsedCurrent = parseInt(currentText);
    if (!isNaN(parsedCurrent) && parsedCurrent < amount) {
        currentAmount = parsedCurrent;
    }

    animationRunning = true;
    chrome.storage.local.set({ hasAnimated: true });

    function step() {
        if (currentAmount >= amount || !animationRunning) {
            robuxElement.innerText = amount.toLocaleString();
            animationRunning = false;
            return;
        }

        const remaining = amount - currentAmount;
        const increment = Math.min(remaining, Math.floor(Math.random() * 4000) + 500);
        currentAmount += increment;
        robuxElement.innerText = currentAmount.toLocaleString();

        const delay = Math.random() * 800 + 200;
        setTimeout(step, delay);
    }

    step();
}

function waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
        const interval = 100;
        let elapsed = 0;

        const check = setInterval(() => {
            const element = document.querySelector(selector);
            if (element) {
                clearInterval(check);
                resolve(element);
            }
            elapsed += interval;
            if (elapsed >= timeout) {
                clearInterval(check);
                reject(`Element "${selector}" not found in time`);
            }
        }, interval);
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'updateFakeRobux') {
        const amount = parseInt(message.amount);
        if (isNaN(amount)) {
            console.error("Invalid Robux amount received");
            sendResponse({ status: "Invalid Robux amount" });
            return;
        }

        chrome.storage.local.set({ fakeRobux: amount, hasAnimated: false }, () => {
            if (message.refresh) {
                window.location.reload();
            }
            animateRobux(amount);
            sendResponse({ status: "Fake Robux updated" });
        });
    } else if (message.type === 'resetRobux') {
        const amount = parseInt(message.amount);
        if (isNaN(amount)) {
            console.error("Invalid reset Robux amount received");
            sendResponse({ status: "Invalid reset Robux amount" });
            return;
        }

        chrome.storage.local.set({ fakeRobux: amount, hasAnimated: true }, () => {
            const robuxElement = document.getElementById('nav-robux-amount');
            if (robuxElement) {
                robuxElement.innerText = amount.toLocaleString();
            }
            if (window.location.pathname === '/transactions') {
                waitForElement('.balance-label.icon-robux-container > span').then((element) => {
                    const textNode = Array.from(element.childNodes).find(
                        (node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim().match(/^\d+$/)
                    );
                    if (textNode) {
                        textNode.textContent = amount.toLocaleString();
                    }
                }).catch((error) => {
                    console.error(error);
                });
            }
            sendResponse({ status: "Robux reset" });
        });
    } else if (message.type === 'refreshPage') {
        window.location.reload();
    }
    return true;
});

console.log('RBXTools content.js loaded on', window.location.pathname);

setTimeout(() => {
    chrome.storage.local.get(['fakeRobux', 'hasAnimated'], (data) => {
        const amount = parseInt(data.fakeRobux);
        const hasAnimated = data.hasAnimated;
        const robuxElement = document.getElementById('nav-robux-amount');
        if (!robuxElement || isNaN(amount)) return;

        if (hasAnimated) {
            robuxElement.innerText = amount.toLocaleString();
        } else {
            animateRobux(amount);
        }
    });

    if (window.location.pathname === '/transactions') {
        chrome.storage.local.get(['fakeRobux', 'hasAnimated'], (data) => {
            const amount = parseInt(data.fakeRobux);
            const hasAnimated = data.hasAnimated;
            waitForElement('.balance-label.icon-robux-container > span').then((element) => {
                const textNode = Array.from(element.childNodes).find(
                    (node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim().match(/^\d+$/)
                );
                if (textNode) {
                    textNode.textContent = amount.toLocaleString();
                }
            }).catch((error) => {
                console.error(error);
            });
        });
    }
}, 500);